import TristateButton from '../Components/button';
export function Savebtn(props) {
  const buttontext = "Save to a new map layer";
  return (

<TristateButton buttontext={buttontext}/>
  );
}
